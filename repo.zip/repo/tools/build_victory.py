"""Generuje assets/victory.map - pokoj "Mission Complete" zlozony z kafelkow.

Format pliku jest taki sam jak w world.map:
    szerokosc wysokosc rozmiar_kafelka pierwszy_solidny_kafelek
a potem szerokosc*wysokosc numerow kafelkow (wiersz po wierszu).
Uzywamy tego samego tileset.bmp, wiec nie trzeba nowej grafiki.
"""
import random
import sys
from pathlib import Path

W, H, TILE = 60, 34, 32          # 60*32 = 1920, 34*32 = 1088 (ekran 1920x1080)
FIRST_SOLID = 598                # id >= 598 to sciana/przeszkoda (jak w world.map)

FLOOR = [164, 165, 166, 167, 168]  # kafelki podlogi z placu przy portalu
PEDESTAL = {                       # cokol portalu z world.map (solidny!)
    0: [None, 825, 826, 827, 828, None],
    1: [837, 838, 839, 840, 841, 842],
    2: [852, 853, 854, 855, 856, 857],
}
PED_X, PED_Y = 27, 12            # lewy gorny rog cokolu (w kafelkach)


def build():
    rng = random.Random(42)
    tiles = [[rng.choice(FLOOR) for _ in range(W)] for _ in range(H)]

    # ramka ze scian, 2 kafelki grubosci - te same wzory co w world.map
    for x in range(W):
        for y, base in ((0, 598), (1, 601), (H - 2, 598), (H - 1, 601)):
            tiles[y][x] = base + x % 3
    for y in range(2, H - 2):
        tiles[y][0] = 598 + y % 3
        tiles[y][1] = 601 + y % 3
        tiles[y][W - 2] = 598 + y % 3
        tiles[y][W - 1] = 601 + y % 3

    # cokol na srodku (solidny - gracz go obejdzie)
    for dy, row in PEDESTAL.items():
        for dx, tid in enumerate(row):
            if tid is not None:
                tiles[PED_Y + dy][PED_X + dx] = tid
    return tiles


def main():
    root = Path(__file__).resolve().parents[1]
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else root / "assets" / "victory.map"
    tiles = build()
    lines = [f"{W} {H} {TILE} {FIRST_SOLID}"]
    lines += [" ".join(map(str, row)) for row in tiles]
    out.write_text("\n".join(lines) + "\n")

    # podglad w konsoli: # sciana/solid, . podloga
    for row in tiles:
        print("".join("#" if t >= FIRST_SOLID else "." for t in row))
    print(f"\nZapisano {out}")


if __name__ == "__main__":
    main()
